package com.blps.lab1.model.cv;

public enum Sex {
    MALE,
    FEMALE
}
