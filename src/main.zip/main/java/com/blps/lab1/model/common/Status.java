package com.blps.lab1.model.common;

public enum Status {
    WAITING,
    ASSIGNED,
    APPROVED
}
