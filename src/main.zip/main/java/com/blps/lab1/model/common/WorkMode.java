package com.blps.lab1.model.common;

public enum WorkMode {
    FULL_TIME,
    PART_TIME,
    VOLUNTEERING,
    FLEXIBLE_HOURS
}
