package com.blps.lab1.model.user;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum Role {
    ROLE_USER,
    ROLE_MODERATOR,
    ROLE_HR
}
