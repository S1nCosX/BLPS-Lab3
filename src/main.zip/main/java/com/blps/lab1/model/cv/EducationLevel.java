package com.blps.lab1.model.cv;

public enum EducationLevel {
    BACHELOR,
    MASTER,
    COLLEGE,
    CANDIDATE_OF_SCIENCES,
    HIGH_SCHOOL
}
