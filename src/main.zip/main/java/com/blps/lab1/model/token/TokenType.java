package com.blps.lab1.model.token;

public enum TokenType {
    BEARER
}
