package com.blps.lab1.utils;

public class ValidationUtils {
    public static String validatePhoneNumber(String phoneNumber) {
        return phoneNumber;
    }
}
